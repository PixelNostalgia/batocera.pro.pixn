 

 Certain portions of this software are based on source code from OpenJDK
(http://openjdk.java.net/)  and  licensed  under  the GNU General Public
License  version  2  (GPLv2)  with   the  Classpath  Exception  (http://
openjdk.java.net/legal/gplv2+ce.html).  For a period of three years from
the date  of your receipt  of  this  software,  Azul  will  provide upon
request, a complete  machine readable  copy of the  source code for such
portions  based  on  OpenJDK on a medium  customarily used  for software
interchange for a charge no more  than the cost of physically performing
source distribution.


  Please email azul_openjdk@azul.com for further information.

  Include this version code in your email:
  zsrc8.66.0.15-jdk8.0.352 e4172629d542c178ac73c10ab7193f24b6d1ab58
  OpenJSSE 1.1.10 987d0c688a001cf8fc476a981af1b0dd371c78e4
  Legacy8uJSSE 1.1.4 60634515a4c252fdadd22d53d0b32337be99876a
  CRS 0.7.2-dd16106b4-169

To read more about Azul products visit https://www.azul.com/products/.
